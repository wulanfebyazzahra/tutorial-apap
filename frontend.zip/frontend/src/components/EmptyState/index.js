import React from "react";

export default function EmptyState() {
  return (
    <>
    <h3 className="text-center">Belum ada item yang dipilih</h3>
    <p className="text-center">Klik salah satu item di List Movies</p>
    </>
  );
}